part of 'splash_bloc.dart';

abstract class SplashEvent {}

class SplashInitEvent extends SplashEvent{}
